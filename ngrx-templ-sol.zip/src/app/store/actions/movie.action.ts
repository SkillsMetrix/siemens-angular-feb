import { createAction, props } from "@ngrx/store";
import { Movie } from "src/app/Models/movie";



export const getMovie=createAction('[Movie] Get Movie')
export const getMovieSuccess=createAction('[Movie] Get Movie Success',(movie:ReadonlyArray<Movie>) => ({movie}))
export const addMovie=createAction('[Movie] Add Movie', (movie:Movie) => movie)
export const addMovieSuccess=createAction('[Movie] Add movie Success',props<{movie: Movie}>())