import { Actions, createEffect, ofType } from "@ngrx/effects";
import { DataService } from "../data.service";
 import { getMovie, getMovieSuccess } from "src/app/store/actions/movie.action";
import {exhaustMap, map } from "rxjs/operators";
import { Injectable } from "@angular/core";


@Injectable({
    providedIn:"root"
})
export class MovieEffects {
    constructor(private action$: Actions, private dataService: DataService) { }
    loadMovies$ = createEffect(() =>
        this.action$.pipe(
            ofType(getMovie),
            exhaustMap(() =>
                this.dataService.getMovies().pipe(
                    map((movies) => getMovieSuccess(movies)),
                    
                )
            )
        )
    )
}