import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Movie } from './Models/movie';
 import { addMovie, getMovie } from './store/actions/movie.action';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {

  newMovie: Movie = new Movie();
  title = 'movieApp';
  constructor(private store: Store) { }


  addNewMovies(): void {
    this.store.dispatch(addMovie(this.newMovie))

  }
}
