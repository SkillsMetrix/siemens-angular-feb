import { Component, Input, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { MovieState } from '../store/reducers/movie.reducers';
import { getMovie } from '../store/actions/movie.action';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.css'],
})
export class MovieListComponent implements OnInit {
 
  movies$=this.store.select('movies')
  constructor(private store: Store<MovieState>) {}

  ngOnInit(): void {
    this.getAllMovies()
  }
  getAllMovies(): void {
    this.store.dispatch(getMovie())
     
  }
}
