import { Component, Input } from '@angular/core';
import { ProjectService } from 'src/app/shared/project.service';
import { UserService } from 'src/app/shared/userservice.service';

@Component({
  selector: 'app-headermain',
  templateUrl: './headermain.component.html',
  styleUrls: ['./headermain.component.css']
})
export class HeadermainComponent {
  @Input()
  mycity='pune'
  profile='https://images.pexels.com/photos/1374510/pexels-photo-1374510.jpeg?auto=compress&cs=tinysrgb&w=600'
  addUser(){
    alert('user is added')
  }
  constructor(private us:UserService,private ps:ProjectService){
    this.userdata=this.us.userData()
    this.projectdata=this.ps.projectData()
  }
  userdata
  projectdata
  getColor(country:string){
     switch(country){
      case 'UK' :
        return 'green'
        case 'USA' :
          return 'blue'
          case 'India' :
            return 'purple'
            default :
            return null
     }
  }
  people:any[]=[
    {
      name:"Alto",
      country:"USA"
    },
    {
      name:"Mira",
      country:"India"
    },
    {
      name:"Sam",
      country:"UK"
    },
    {
      name:"Sameer",
      country:"India"
    }
  ]
}
