import { Component, ViewChild } from '@angular/core';
import { FooterComponent } from './footer/footer.component';

@Component({
  selector: 'app-mainapp',
  templateUrl: './mainapp.component.html',
  styleUrls: ['./mainapp.component.css']
})
export class MainappComponent {

  @ViewChild(FooterComponent)
  private vc={} as FooterComponent


  Inc(){
    this.vc.increment()
  }
  Dec(){
    this.vc.decrement()
  }
}
