import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent {

  message:string=''
  count:number=0

  increment(){
    this.count=this.count+1
    this.message= "Counter " + this.count
  }
  decrement(){
    this.count=this.count-1
    this.message= "Counter " + this.count
  }
}
