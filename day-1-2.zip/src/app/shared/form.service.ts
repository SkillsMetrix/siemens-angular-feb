import { HttpClient  } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FormService {

  constructor(private http:HttpClient){}

  addUserToDB(data:any){

    this.http.post('https://siemens-angular-b5c28-default-rtdb.firebaseio.com/mydata.json',data)
    .subscribe(data =>{
      console.log(data);
      
    })
     
  }
loadDataFromDB(){
  this.http.get('https://siemens-angular-b5c28-default-rtdb.firebaseio.com/mydata.json')
    .subscribe(data =>{
      console.log(data);
      
    })
}
   
}
