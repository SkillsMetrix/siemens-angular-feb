import { Injectable } from "@angular/core";


@Injectable()
export class ProjectService {

    projectData():string[]{
        return ['HRMS','Finance','HC']
    }
}