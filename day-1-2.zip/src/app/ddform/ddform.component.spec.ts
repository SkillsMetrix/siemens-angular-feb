import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DdformComponent } from './ddform.component';

describe('DdformComponent', () => {
  let component: DdformComponent;
  let fixture: ComponentFixture<DdformComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DdformComponent]
    });
    fixture = TestBed.createComponent(DdformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
