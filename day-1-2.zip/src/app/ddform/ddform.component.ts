import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-ddform',
  templateUrl: './ddform.component.html',
  styleUrls: ['./ddform.component.css']
})
export class DdformComponent {
  // works like ngForm
  myform: FormGroup
  //form controls
  uname: FormControl
  pass: FormControl
  email: FormControl
  city: FormControl
  gender: FormControl

  constructor(){
    this.createControls()
    this.createForm()
  }
  //maintain relationship
  createForm() {
    this.myform = new FormGroup({
      uname: this.uname,
      pass: this.pass,
      email: this.email,
      city: this.city,
      gender:this.gender
    })
  }
  // define controls
  genders=['male','female','others']
  createControls() {
    this.uname = new FormControl('',Validators.required)
    this.pass = new FormControl('',[Validators.required,Validators.minLength(6)])
    this.email = new FormControl('',[Validators.required,Validators.email,this.emailDomainValidator])
    this.city = new FormControl('')
    this.gender=new FormControl('')
  }

  addUser() {
console.log(this.myform.value);

  }
  emailDomainValidator(control:FormControl){
    let email= control.value
    if(email && email.indexOf('@')!=-1) {
      let[_,domain]= email.split('@')
      if(domain !== "yahoo.com"){
        return {
          emailDomain:{
            parsedDomain:domain
          }
        }
      }

    }
    return null
  }
}
