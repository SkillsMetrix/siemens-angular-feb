import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { MainappComponent } from './mainapp/mainapp.component';
import { HeaderComponent } from './mainapp/header/header.component';
import { HeadermainComponent } from './mainapp/header/headermain/headermain.component';
import { FooterComponent } from './mainapp/footer/footer.component';
import { UserService } from './shared/userservice.service';
import { ProjectService } from './shared/project.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ConditionalComponent } from './conditional/conditional.component';
import { FormComponent } from './form/form.component';
import { DdformComponent } from './ddform/ddform.component'
import { HttpClientModule } from '@angular/common/http'
@NgModule({
  // it contains all the components,directives and Pipes
  declarations: [
    AppComponent,
    MainappComponent,
    HeaderComponent,
    HeadermainComponent,
    FooterComponent,
    ConditionalComponent,
    FormComponent,
    DdformComponent
  ],
  // contains all the modules
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule,HttpClientModule
  ],
  //contains all the services
  providers: [UserService,ProjectService],
  // contains all the Initial bootstrap file
  bootstrap: [AppComponent]
})
export class AppModule { }
