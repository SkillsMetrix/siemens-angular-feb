import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormService } from '../shared/form.service';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent {

  constructor(private fs:FormService){
    this.loadData()
  }
  addUser(nf:NgForm){
   this.fs.addUserToDB(nf.value)
    
  }
  loadData(){
    this.fs.loadDataFromDB()
  }
}
